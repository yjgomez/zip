package administracion.tpo.modelo;

public enum Estado {

	nuevo, abierto, enProceso, desestimado, anulado, terminado 
	
}
