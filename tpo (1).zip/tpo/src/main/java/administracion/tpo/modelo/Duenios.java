package administracion.tpo.modelo;
import jakarta.persistence.*;

public class Duenios {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int identificador;
	
	
	private String documento;

}
