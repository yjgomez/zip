package administracion.tpo;

import administracion.tpo.dao.*;
import administracion.tpo.modelo.*;
import administracion.tpo.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


import java.util.List;
import java.util.Optional;

@SpringBootApplication
public class TpoApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(TpoApplication.class, args);
	}

	@Autowired
	private IRepositoryPersona repositoryPersona;
	@Autowired
	private IRepositoryEdificio repositoryEdificio;
	@Autowired
	private IRepositoryUnidad repositoryUnidad;
	@Autowired
	private IRepositoryImagen repositoryImagen;
	@Autowired
	private IRepositoryReclamo repositoryReclamo;

	@Override
	public void run(String... args) throws Exception {

		/*
		List<Edificio> edificios = EdificioDAO.getInstance().getAll(repositoryEdificio);
		List<Unidad> unidades = UnidadDAO.getInstance().getAll(repositoryUnidad);
		List<Persona> personas = PersonaDAO.getInstance().getAll(repositoryPersona);
		List<Reclamo> reclamos = ReclamoDAO.getInstance().getAll(repositoryReclamo);

		for (Edificio edificio : edificios) {
			System.out.println(edificio.toString());
		}

		for (Unidad unidad : unidades) {
			System.out.println(unidad.toString());
		}

		for (Persona persona : personas) {
			System.out.println(persona.toString());
		}
		for (Reclamo reclamo : reclamos) {
			System.out.println(reclamo.toString());
		}
		*/
		
		/*
		Optional<Persona> p=PersonaDAO.getInstance().getById("DNI92876004", repositoryPersona);
		System.out.println(p);
		*/

		/*
		List<Imagen> imagenList = ImagenDAO.getInstance().getAll(repositoryImagen);

		for (Imagen i : imagenList) {
			System.out.println(i.toString());
		}
		*/
		
		/* agregar una nueva persona
		Persona nueva=new Persona("DNI893012344","PEPE, JULIAN");
		PersonaDAO.getInstance().save(nueva, repositoryPersona);
		*/
		
		/* comprobar si esa persona se guardó correctamente
		 * el Optional se usa si ese objeto a retornar no existe
		Optional<Persona> p2=PersonaDAO.getInstance().getById("DNI893012344", repositoryPersona);
		System.out.println(p2);
		*/
		
		//se elimina a la persona agregada anteriormente
		//PersonaDAO.getInstance().delete("DNI893012344", repositoryPersona);
		
		/*
		List<Unidad> unidades = UnidadDAO.getInstance().getAll(repositoryUnidad);
		for (Unidad unidad : unidades) {
			System.out.println(unidad.toString());
		}
		*/
		
		/*
		List<Persona> personas = PersonaDAO.getInstance().getAll(repositoryPersona);
		for(Persona p:personas) {
			System.out.println(p.toString());
		}*/
		
		List<Unidad> unidades = UnidadDAO.getInstance().getAll(repositoryUnidad);
		for (Unidad unidad : unidades) {
			System.out.println(unidad.toString());
		}
		
		




	}
}
