package administracion.tpo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpoApplicationTests {

	@Test
	void contextLoads() {
	}

}
